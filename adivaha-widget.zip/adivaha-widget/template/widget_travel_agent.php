<html>
<?php
$tablename = "adh_widget"; 
if(isset($_REQUEST['submit'])){
	$name = $_REQUEST['forModel'];
	
	$title = $_REQUEST['title'];
	$text = $_REQUEST['text'];

	//$image =  $_REQUEST['dest_image'];
	 $file_extension = pathinfo($_FILES["dest_image"]["name"], PATHINFO_EXTENSION);
	  $fileFormateArr = array('png','jpg','jpeg','svg');
	  if(in_array($file_extension,$fileFormateArr)){
	  	$tmpname = $_FILES["dest_image"]["tmp_name"];
	  	$fileOname = $_FILES["dest_image"]["name"];
	  	$target = PLUGIN_DIR."img/".$fileOname;

	  	move_uploaded_file($tmpname,$target);
	  	 $destUrl = $_REQUEST['destUrl'];
	if($name!=''){
		$data = array('model'=>$name,'title'=>$title,'text'=>$text,'image'=>$fileOname);
		$wpdb->query("insert into ".$tablename." set title='travel_agent', data='".addslashes(json_encode($data))."',name='".$name."', delete_status='0',date_time=now()");
	}
		
	}else{
		echo "File Formate Not Supporting";
	}

}
?>
<body>
	<style>
		.mytble{
	width:100%;margin-top:4%;
}
.mytble td{
	padding-left:12px;
	
}
#widgetbtn{
	padding: 4px 8px;
    position: relative;
    top: -3px;
    text-decoration: none;
    border: 1px solid #0071a1;
    border-radius: 2px;
    text-shadow: none;
    font-weight: 600;
    font-size: 13px;
    line-height: normal;
    color: #0071a1;
    background: #f3f5f6;
    cursor: pointer;
}
.overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100px;
  opacity: 0;
  transition: .5s ease;
  background-color: #abadad;
}
.overlay .text{
	    font-size: 48px;
    text-align: center;
    margin-top: 9%;
}
.imagehover{
	position: relative;
}
.imagehover:hover .overlay {
  opacity: 1;
}
		input,select{float:left;
			width:100%;
			margin:5px;}
			form{width:50%;}
	</style>
	<h2>Add Travel Agent<button id="widgetbtn">Add New</button></h2>
	
	<div id="addnewwidget" style="display:none;">
	<form action="#" method="post" enctype='multipart/form-data'>
		<select name="forModel">
			<option value="">Select Module</option>
			<option value="flight">Flight</option>
			<option value="hotel">Hotel</option>
			<option value="car">Car</option>
			<option value="transfer">Transfer</option>
		</select>
		<input type="text" placeholder="Separator Title (Optional)" name="title">
		 <h5 style="float:left;margin:6px;" >Select Logo</h5>
   <input type="file" name="dest_image">
		<input type="submit" name="submit" value="submit">
	</form>
</div>
	<?php echo do_shortcode('[Get_travel_agent]');?>
	</body>
<html>

<script>
	jQuery(document).ready(function(){
		jQuery("#widgetbtn").click(function(){
			jQuery("#addnewwidget").slideToggle();

			
		})
	})
	</script>