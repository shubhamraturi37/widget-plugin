<html>
<?php

$tablename = "adh_widget"; 
if(isset($_REQUEST['submit'])){
	
	$name = $_REQUEST['dest_name'];
	
	$description = $_REQUEST['destDescription'];
	$rating = $_REQUEST['rating'];
	$rating = $_REQUEST['rating'];
	$review = $_REQUEST['review'];
	//$image =  $_REQUEST['dest_image'];
	 $data = array($_REQUEST['common']);
		$results = $wpdb->get_results("select * from  ".$tablename." where title='bannerData'");
		if(count($results)==0){
		$wpdb->query("insert into ".$tablename." set title='bannerData', data='".addslashes(json_encode($data))."',name='".$name."', delete_status='0',date_time=now()");
	}else{
		$wpdb->query("update ".$tablename." set  data='".addslashes(json_encode($data))."',name='".$name."', delete_status='0',date_time=now() where title='bannerData'");
	}
	
		
	

}
$data = $wpdb->get_results("select data from  ".$tablename." where title='bannerData'");

 $dataArr = json_decode($data[0]->data);
  

?>

	<style>
		.mytble{
	width:100%;margin-top:4%;
}
.mytble td{
	padding-left:12px;
	
}
#widgetbtn{
	padding: 4px 8px;
    position: relative;
    top: -3px;
    text-decoration: none;
    border: 1px solid #0071a1;
    border-radius: 2px;
    text-shadow: none;
    font-weight: 600;
    font-size: 13px;
    line-height: normal;
    color: #0071a1;
    background: #f3f5f6;
    cursor: pointer;
}
.overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100px;
  opacity: 0;
  transition: .5s ease;
  background-color: #abadad;
}
.overlay .text{
	    font-size: 48px;
    text-align: center;
    margin-top: 9%;
}
.imagehover{
	position: relative;
}
.imagehover:hover .overlay {
  opacity: 1;
}
		input,select{float:left;
			width:100%;
			margin:5px;}
			form{width:50%;}
	</style>
	<div style="float: left;width: 100%;margin-top: 35px;">
    <label class="bannerlabel"><i class="fa fa-photos"></i>&nbsp;<span>Upload Gallery</span> </label><br>
    <span class="bannertext separator">Upload the Banner details. <!--Suggested 4-6 words for title and 15-20 words for content--></span>
  <form method="POST" action="#">
  <div class="adh_interface_div">
      <label>Video Url </label>
      <label class="informaton_adi">Video Url </label>
      <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_videourlput);?>" name="common[banner_1001_videourlput]" id="videourlput">
    </div>
  
  
   <div class="adh_interface_div">
      <label>Flights Ttile </label>
      <label class="informaton_adi">Flights Ttile Text</label>
	<input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_flightBannerText);?>" name="common[banner_1001_flightBannerText]" id="flightBannerText">  
  </div>
	
	 <div class="adh_interface_div">
      <label>Hotels Ttile</label>
      <label class="informaton_adi">Hotels Ttile Text</label>
     <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_hotelBannerText);?>" name="common[banner_1001_hotelBannerText]" id="hotelBannerText">
	 
    </div>
	
	
	 <div class="adh_interface_div">
      <label>Car Hire Ttile</label>
      <label class="informaton_adi">Car Hire Text</label>
     <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_carBannerText);?>" name="common[banner_1001_carBannerText]" id="carBannerText">
    </div>
	
	 <div class="adh_interface_div">
      <label>Airport Transfers Ttile</label>
      <label class="informaton_adi">Airport Transfers Ttile Text</label>
	  <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_transferBannerText);?>" name="common[banner_1001_transferBannerText]" id="transferBannerText">
     
    </div>
	<div class="adh_interface_div">
      <label>Inspiration Trip Ttile</label>
      <label class="informaton_adi">Inspiration Trip Ttile Text</label>
	  <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_inspiration_trip);?>" name="common[banner_1001_inspiration_trip]" id="Inspiration">
     
    </div>
	<div class="adh_interface_div">
      <label>Inspiration Trip Sub Ttile</label>
      <label class="informaton_adi">Inspiration Trip Sub Ttile Text</label>
	  <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_inspiration_trip_sub);?>" name="common[banner_1001_inspiration_trip_sub]" id="Inspiration_sub">
     
    </div>
	<div class="adh_interface_div">
      <label>Popular Destination Ttile</label>
      <label class="informaton_adi">Popular Destination Ttile Text</label>
	  <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_popular_destination);?>" name="common[banner_1001_popular_destination]" id="Popular_destination">
     
    </div>
	
	<div class="adh_interface_div">
      <label>Popular Destination Sub Ttile</label>
      <label class="informaton_adi">Popular Destination Sub Ttile Text</label>
	  <input class="width2" type="text" value="<?php echo stripslashes($dataArr[0]->banner_1001_popular_destination_sub);?>" name="common[banner_1001_popular_destination_sub]" id="Popular_destination_sub">
     
    </div>
	
	
  
  
    
	<input type ="submit" name="submit" value="Submit">
	</form>
	</div>
<html>

