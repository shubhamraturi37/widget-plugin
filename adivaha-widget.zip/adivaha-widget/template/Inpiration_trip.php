
<?php 

$getdata = $wpdb->get_results("select * from adh_widget where delete_status='0' and title='trip' limit 4");
$data = $wpdb->get_results("select data from adh_widget where title='bannerData'");
$inspirationTrip = json_decode($data[0]->data);
$inspirationTrip= $inspirationTrip[0];

?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo PLUGIN_URL.'css/'?>automiz.css">
   <div class="adi-max-width" style="margin-top:50px;">
    <div class="">
        <div class="">
            <h2 class="body-title"><!--Trending Tours--><?php if($inspirationTrip->banner_1001_inspiration_trip==''){echo _e('Need some inspiration?','adivaha-widget');}else{
						echo _e($inspirationTrip->banner_1001_inspiration_trip,'adivaha-widget');
					}?></h2>
					 <p class="body-paragraph text-center"><?php if($inspirationTrip->banner_1001_inspiration_trip_sub==''){echo '';}else{
						echo _e($inspirationTrip->banner_1001_inspiration_trip_sub,'adivaha-widget');
					}?></p>
        </div>
    </div>
    <div class="search_result_page adi-full">
        <div class="owl_stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s;">
            <?php 
        foreach($getdata as $key=>$data){
    $dataArr = json_decode($data->data,true);

            ?>
            <div class="owl_item active" style="width: 25%; float: left;">
                <div class="item-service grid-item has-matchHeight" style="">
                    <div class="service-border">
                        <div class="thumb">
                            <!--<span class="st_sale_class box_sale sale_small">11%</span>-->
                            <a
                                href="<?php echo $dataArr['url']?>"
                                class="login"
                            >
                                <div class="service-add-wishlist" title="Add to wishlist"><i class="fa fa-heart"></i></div>
                            </a>
                            <div class="service-tag bestseller"><div class="feature_class st_featured featured"><?php echo _e('Featured','adivaha-widget');?></div></div>
                           
                            <a
                                href="<?php echo $dataArr['url']?>"
                            >
                                <img width="680" height="500" src="<?php echo PLUGIN_URL.'img/'.$dataArr['image']; ?>" class="img_responsive" alt="WordPress Booking Theme" />
                            </a>
                        </div>
                        <div class="thumb_body">
                            <p class="service-location plr15">
                                <i class="input-icon field-icon fa">
                                    <svg width="15px" height="15px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <desc>Created with Sketch.</desc>
                                        <defs></defs>
                                        <g id="Ico_maps" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                                            <g id="Group" transform="translate(4.000000, 0.000000)" stroke="#666666">
                                                <g id="pin-1" transform="translate(-0.000000, 0.000000)">
                                                    <path
                                                        d="M15.75,8.25 C15.75,12.471 12.817,14.899 10.619,17.25 C9.303,18.658 8.25,23.25 8.25,23.25 C8.25,23.25 7.2,18.661 5.887,17.257 C3.687,14.907 0.75,12.475 0.75,8.25 C0.75,4.10786438 4.10786438,0.75 8.25,0.75 C12.3921356,0.75 15.75,4.10786438 15.75,8.25 Z"
                                                        id="Shape"
                                                    ></path>
                                                    <circle id="Oval" cx="8.25" cy="8.25" r="3"></circle>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </i>
                                <!--Holiday Inn Express Manchester - Salford Quays--><?php echo _e($dataArr['description'],'adivaha-widget')?>
                            </p>
                            <!--<h4 class="service-title plr15"><a href="https://triparison.com/en/hotel-detail/#/hotels?dest=Holiday%20Inn%20Express%20Manchester%20-%20Salford%20Quays&checkIn=2020-08-15&checkOut=2020-08-16&marker=276493&adults=2&children=&language=en&currency=GBP&cityId=7945&from_mobile=true&locationId=7945&hotelId=343423&searchId=2b2af77b-5bbb-45f0-81bd-ee31109274d7&hotelName=Holiday%20Inn%20Express%20Manchester%20-%20Salford%20Quays">United Kingdom</a></h4>-->
                            <h4 class="service-title plr15" style="margin:0px;">
                                <a
                                    href="<?php echo $dataArr['url']?>"
                                >
                                    <?php echo _e($dataArr['name'],'adivaha-widget')?>
                                </a>
                            </h4>
                            <div class="service-review plr15">
                                <ul class="icon-group text-color booking-item-rating-stars">
                                    <?php 
                                    for($i=0;$i<round($dataArr['rating']);$i++){
                                        ?>
                                   
                                    <li style="margin:3px"><i class="fa fa-star"></i></li>
                                   
                                <?php }
                                  for($c=5;$c>round($dataArr['rating']);$c--){ 
                                     ?>
                                    <li style="margin:3px"><i class="fa fa-star-o"></i></li>
                                   <?php }?>
                                </ul>
                                <span class="review" style="float:right;margin-top:5px;"><!--4100 Reviews--><?php echo $dataArr['review']?> Reviews</span>
                            </div>
                            <div class="section-footer" style="display: none;">
                                <div class="footer-inner plr15">
                                    <div class="service-duration">
                                        <!--<i class="input-icon field-icon fa"><svg height="16px" width="16px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve"><g fill="#5E6D77"><path d="M12,23.25C5.797,23.25,0.75,18.203,0.75,12C0.75,5.797,5.797,0.75,12,0.75c6.203,0,11.25,5.047,11.25,11.25 C23.25,18.203,18.203,23.25,12,23.25z M12,2.25c-5.376,0-9.75,4.374-9.75,9.75s4.374,9.75,9.75,9.75s9.75-4.374,9.75-9.75 S17.376,2.25,12,2.25z"></path><path d="M15.75,16.5c-0.2,0-0.389-0.078-0.53-0.22l-2.25-2.25c-0.302,0.145-0.632,0.22-0.969,0.22c-1.241,0-2.25-1.009-2.25-2.25 c0-0.96,0.615-1.808,1.5-2.121V5.25c0-0.414,0.336-0.75,0.75-0.75s0.75,0.336,0.75,0.75v4.629c0.885,0.314,1.5,1.162,1.5,2.121 c0,0.338-0.075,0.668-0.22,0.969l2.25,2.25c0.292,0.292,0.292,0.768,0,1.061C16.139,16.422,15.95,16.5,15.75,16.5z M12,11.25 c-0.414,0-0.75,0.336-0.75,0.75s0.336,0.75,0.75,0.75s0.75-0.336,0.75-0.75S12.414,11.25,12,11.25z"></path></g></svg></i> 3 days -->
                                        non refundable
                                    </div>
                                    <div class="service-price">
                                        <span>
                                            <i class="input-icon field-icon fa">
                                                <svg width="10px" height="16px" viewBox="0 0 11 18" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                                    <desc>Created with Sketch.</desc>
                                                    <defs></defs>
                                                    <g id="Hotel-layout" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                        <g id="Room_Only_Detail_1" transform="translate(-135.000000, -4858.000000)" fill="#ffab53" fill-rule="nonzero">
                                                            <g id="nearby-hotel" transform="translate(130.000000, 4334.000000)">
                                                                <g id="h1-g" transform="translate(5.000000, 136.000000)">
                                                                    <g id="hotel-grid">
                                                                        <g id="price" transform="translate(0.000000, 383.000000)">
                                                                            <g id="thunder" transform="translate(0.000000, 5.000000)">
                                                                                <path
                                                                                    d="M10.0143234,6.99308716 C9.91102517,6.83252576 9.73362166,6.73708716 9.54386728,6.73708716 L5.61404272,6.73708716 L5.61404272,0.561648567 C5.61404272,0.296666111 5.42877956,0.0676134793 5.16941114,0.0125959355 C4.90555149,-0.0435444154 4.64730587,0.0923152337 4.5395164,0.333718743 L0.0482883306,10.4389819 C-0.0291853536,10.6118942 -0.0123432484,10.8139994 0.0909549973,10.9723152 C0.194253243,11.1317538 0.371656752,11.2283152 0.561411138,11.2283152 L4.4912357,11.2283152 L4.4912357,17.4037538 C4.4912357,17.6687363 4.67649886,17.8977889 4.93586728,17.9528065 C4.97516552,17.9606661 5.01446377,17.9651573 5.05263921,17.9651573 C5.27046377,17.9651573 5.47369184,17.8382801 5.56576201,17.6316837 L10.0569901,7.5264205 C10.133341,7.35238541 10.1187445,7.15252576 10.0143234,6.99308716 Z"
                                                                                    id="Shape"
                                                                                ></path>
                                                                            </g>
                                                                        </g>
                                                                    </g>
                                                                </g>
                                                            </g>
                                                        </g>
                                                    </g>
                                                </svg>
                                            </i>
                                            <span class="fr_text">from</span>
                                        </span>
                                        <span class="price"><span class="text-lg lh1em item"> £ 38</span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php }?>
            
            
        </div>
        <div class="owl-nav disabled" style="display: none;">
            <button type="button" role="presentation" class="owl-prev disabled"><span aria-label="Previous">‹</span></button><button type="button" role="presentation" class="owl-next disabled"><span aria-label="Next">›</span></button>
        </div>
        <div class="owl-dots disabled" style="display: none;"></div>
    </div>
</div>


