<html>
<h4>Banner Shortcodes</h4>
<p>[Adivaha_Banner]</p>
<br>

<h4>Seprator Shortcode</h4>
<p>[Adivaha_Seprator]</p>
<br>

<h4>Inspiration Trip Shortcodes</h4>
<p>[Adivaha_Inspiration_trip]</p>
<br>

<h4>Popular Destination Shortcodes</h4>
<p>[Adivaha_Popular_Destination]</p>
<br>







<h5>Note:</h5>
<p>
If you feel that the image is conflating with each other, then rename the image file and upload it</p>

</html>