<?php
global $wpdb;
global $globRest;
global $globCommon;
$data = $wpdb->get_results("select * from adh_widget where title='Separator' and delete_status='0'");
$flight = array();
$hotel = array();
$car = array();
$transfer = array();
foreach ($data as $key => $dataArr) {

    if ($dataArr->name == 'flight') {
        array_push($flight, json_decode($dataArr->data, true));
    }
    if ($dataArr->name == 'hotel') {
        array_push($hotel, json_decode($dataArr->data, true));
    }
    if ($dataArr->name == 'car') {
        array_push($car, json_decode($dataArr->data, true));
    }
    if ($dataArr->name == 'transfer') {
        array_push($transfer, json_decode($dataArr->data, true));
    }
}



?>
<div id="adivahaDestinationsZeroZeroNine">
    <div class="new_separater adi-full">
        <div class="new_separater_section">
            <div class="adi-max-width">
                <div class="new_separater_flight active">
                    <?php
                    foreach ($flight as $key => $data) {
                        if ($key == 3) {
                            break;
                        }
                    ?>
                        <div class="col-md">
                            <div class="jsx-2221386506 root">
                                <div class="no-gutters row">
                                    <div class="col-auto"><img alt="" src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" /></div>
                                    <div class="col">
                                        <h5 class="jsx-2221386506"><?php echo _e(stripslashes($data['title']), 'adivaha-widget'); ?></h5>
                                        <p class="jsx-2221386506 description"><?php echo _e(stripslashes($data['text']), 'adivaha-widget'); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>

                </div>
                <div class="new_separater_hotel" style="display: none;">
                    <?php

                    foreach ($hotel as $key => $data) {
                        if ($key == 3) {
                            break;
                        }
                    ?>
                        <div class="col-md">
                            <div class="jsx-2221386506 root">
                                <div class="no-gutters row">
                                    <div class="col-auto"><img alt="" src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" /></div>
                                    <div class="col">
                                        <h5 class="jsx-2221386506"><?php echo _e(stripslashes($data['title']), 'adivaha-widget'); ?></h5>
                                        <p class="jsx-2221386506 description"><?php echo _e(stripslashes($data['text']), 'adivaha-widget') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php

                    }
                    ?>


                </div>
                <div class="new_separater_carhire" style="display: none;">
                    <?php
                    foreach ($car as $key => $data) {
                        if ($key == 3) {
                            break;
                        }
                    ?>
                        <div class="col-md">
                            <div class="jsx-2221386506 root">
                                <div class="no-gutters row">
                                    <div class="col-auto"><img alt="" src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" /></div>
                                    <div class="col">
                                        <h5 class="jsx-2221386506"><?php echo _e(stripslashes($data['title']), 'adivaha-widget') ?></h5>
                                        <p class="jsx-2221386506 description"><?php echo _e(stripslashes($data['text']), 'adivaha-widget') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>


                </div>
                <div class="new_separater_cartransfer" style="display: none;">
                    <?php
                    foreach ($transfer as $key => $data) {
                        if ($key == 3) {
                            break;
                        }
                    ?>
                        <div class="col-md">
                            <div class="jsx-2221386506 root">
                                <div class="no-gutters row">
                                    <div class="col-auto"><img alt="" src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" /></div>
                                    <div class="col">
                                        <h5 class="jsx-2221386506"><?php echo _e(stripslashes($data['title']), 'adivaha-widget'); ?></h5>
                                        <p class="jsx-2221386506 description"><?php echo _e(stripslashes($data['text']), 'adivaha-widget') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <?php
    $data = $wpdb->get_results("select * from adh_widget where title='travel_agent' and delete_status='0'");
    $flight = array();
    $hotel = array();
    $car = array();
    $transfer = array();
    foreach ($data as $key => $dataArr) {

        if ($dataArr->name == 'flight') {
            array_push($flight, json_decode($dataArr->data, true));
        }
        if ($dataArr->name == 'hotel') {
            array_push($hotel, json_decode($dataArr->data, true));
        }
        if ($dataArr->name == 'car') {
            array_push($car, json_decode($dataArr->data, true));
        }
        if ($dataArr->name == 'transfer') {
            array_push($transfer, json_decode($dataArr->data, true));
        }
    }

    ?>
    <div class="body-parts adi-full" style="">
        <div class="flightimagecss book_a_flight logo_mainclass" style="display: block;">
            <div class="adi-max-width">
                <div class="row flight_head">
                    <div class="text-center mt-2 mb-2 mb-md-3">
                        <h5 class="jsx-780071979"><?php echo _e('Compare prices from leading airlines and travel agents', 'adivaha-widget') ?></h5>
                    </div>
                </div>
                <div class="row flight_logo">
                    <?php
                    foreach ($flight as $key => $data) {
                        if ($key == 5) {
                            break;
                        }
                    ?>
                        <div class="flight-logo col-3 col-md-2 offset-md-1">
                            <a href="javascript:void(0);" rel="noopener noreferrer" class="jsx-780071979"><img src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" alt="<?php echo stripslashes($data['title']); ?>" class="" /></a>
                        </div>
                    <?php

                    } ?>




                </div>
            </div>
        </div>
        <div class="hotelimagecss book_a_hotle logo_mainclass" style="display: none;">
            <div class="adi-max-width">
                <div class="row flight_head">
                    <div class="text-center mt-2 mb-2 mb-md-3">
                        <h5 class="jsx-780071979"><?php echo _e('Compare prices from leading airlines and travel agents', 'adivaha-widget') ?></h5>
                    </div>
                </div>
                <div class="row flight_logo">
                    <?php
                    foreach ($hotel as $key => $data) {
                        if ($key == 5) {
                            break;
                        }
                    ?>
                        <div class="flight-logo col-3 col-md-2 offset-md-1">
                            <a href="javascript:void(0);" rel="noopener noreferrer" class="jsx-780071979"><img src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" alt="<?php echo stripslashes($data['title']); ?>" class="" /></a>
                        </div>
                    <?php

                    } ?>
                </div>
            </div>
        </div>
        <div class="car_booking_logo book_a_car logo_mainclass" style="display: none;">
            <div class="adi-max-width">
                <div class="row flight_head">
                    <div class="text-center mt-2 mb-2 mb-md-3">
                        <h5 class="jsx-780071979"><?php echo _e('Compare prices from leading airlines and travel agents', 'adivaha-widget') ?></h5>
                    </div>
                </div>
                <div class="row flight_logo">
                    <?php
                    foreach ($car as $key => $data) {
                        if ($key == 5) {
                            break;
                        }
                    ?>
                        <div class="flight-logo col-3 col-md-2 offset-md-1">
                            <a href="javascript:void(0);" rel="noopener noreferrer" class="jsx-780071979"><img src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" alt="<?php echo stripslashes($data['title']); ?>" class="" /></a>
                        </div>
                    <?php

                    } ?>
                </div>
            </div>
        </div>
        <div class="airport_transfers_logo book_a_car_transfers logo_mainclass" style="display: none;">
            <div class="adi-max-width">
                <div class="row flight_head">
                    <div class="text-center mt-2 mb-2 mb-md-3">
                        <h5 class="jsx-780071979"><?php echo _e('Compare prices from leading airlines and travel agents', 'adivaha-widget') ?></h5>
                    </div>
                </div>
                <div class="row flight_logo">
                    <?php
                    foreach ($transfer as $key => $data) {
                        if ($key == 5) {
                            break;
                        }
                    ?>
                        <div class="flight-logo col-3 col-md-2 offset-md-1">
                            <a href="javascript:void(0);" rel="noopener noreferrer" class="jsx-780071979"><img src="<?php echo PLUGIN_URL . 'img/' . $data['image']; ?>" alt="<?php echo stripslashes($data['title']); ?>" class="" /></a>
                        </div>
                    <?php

                    } ?>
                </div>
            </div>
        </div>

    </div>
</div>