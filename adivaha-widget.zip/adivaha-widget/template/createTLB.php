<?php
global $wpdb;

$charset_collate = $wpdb->get_charset_collate();
$tablename =  "adh_widget"; 
$sql = "CREATE TABLE $tablename (
  id mediumint(9) NOT NULL AUTO_INCREMENT,
   title tinytext NOT NULL,
  data  text NOT NULL,
  name  varchar(30) DEFAULT '' NOT NULL,
  delete_status varchar(20) DEFAULT '' NOT NULL,
  date_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY  (id)
) $charset_collate;";

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
?>