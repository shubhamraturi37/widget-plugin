
<?php 

$getdata = $wpdb->get_results("select * from adh_widget where delete_status='0' and title='pop_dest'");
$datassss = $wpdb->get_results("select data from adh_widget where title='bannerData'");
$popdestination = json_decode($datassss[0]->data);
$popdestination= $popdestination[0];

foreach($getdata as $key=>$data){
	$dataArr[] = array(json_decode($data->data,true));
}

?>
    <link rel="stylesheet" href="<?php echo PLUGIN_URL.'css/'?>automiz.css">
    <div class="shortcode_1003 adi-full container" style="margin-top:50px;width:100%;max-width:100%">
        <div class="adi-max-width">
            <div class="body-parts adi-full" style="">
                <div class="section-one" style="padding-bottom: 20px;">
                    <h2 class="body-title padding-20"><?php 
					if($popdestination->banner_1001_popular_destination==''){echo _e('Popular Destinations','adivaha-widget');}else{
						echo _e($popdestination->banner_1001_popular_destination,'adivaha-widget');
					}?></h2>
                    <p class="body-paragraph text-center"><?php if($popdestination->banner_1001_popular_destination_sub==''){echo _e('The most popular places in the world','adivaha-widget');}else{
						echo _e($popdestination->banner_1001_popular_destination_sub,'adivaha-widget');
					}?></p>
                    <div class="section-two adi-full" style="margin-top: 25px;">
                        <div class="adi-max-width" max-width="100%">
                            <div class="adi-col-6 adi-left padding-right-10 padding-bottom-10 oneFiex1">
                                <div class="box">
                                    <span class="message"><b class="">BEST DEAL</b></span> <img alt="" src="<?php echo PLUGIN_URL.'img/'.$dataArr[0][0]['image']?>" />
                                    <div class="box-content padding-20">
                                        <p class="text-color-white"><?php echo _e($dataArr[0][0]['name'],'adivaha-widget')?></p>
                                        <h3 class="text-color-white"><?php echo _e($dataArr[0][0]['description'],'adivaha-widget')?></h3>
                                    </div>
                                    <div class="hoverlayboxcolor">
                                        <a href="<?php echo $dataArr[0][0]['url']?>" class="city-text text-color-white"><?php echo  _e($dataArr[0][0]['name'],'adivaha-widget');?> </a>
                                        <a href="<?php echo $dataArr[0][0]['url']?>" class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde">Find The Best</a>
                                    </div>
                                    <div class="hover-overlay"></div>
                                </div>
                            </div>
                            <div class="adi-col-4 adi-right oneFiex2 padding-bottom-10">
                                <div class="margin-bottom-10">
                                    <div class="box">
                                        <span class="message"><b class="">BEST DEAL</b></span><img alt="" src="<?php echo PLUGIN_URL.'img/'.$dataArr[1][0]['image']?>" />
                                        <div class="box-content padding-20">
                                            <p class="text-color-white"><?php echo _e($dataArr[1][0]['name'],'adivaha-widget')?></p>
                                            <h3 class="text-color-white"><?php echo _e($dataArr[1][0]['description'],'adivaha-widget');?></h3>
                                        </div>
                                        <div class="hoverlayboxcolor">
                                            <a href="<?php echo $dataArr[1][0]['url']?>" class="city-text text-color-white"><?php echo _e($dataArr[1][0]['name'],'adivaha-widget')?></a>
                                            <a href="<?php echo $dataArr[1][0]['url']?>" class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde">Find The Best</a>
                                        </div>
                                        <div class="hover-overlay"></div>
                                    </div>
                                </div>
                                <div class="box">
                                    <span class="message"><b class="">BEST DEAL</b></span> <img alt="" src="<?php echo PLUGIN_URL.'img/'.$dataArr[2][0]['image']?>" />
                                    <div class="box-content padding-20">
                                        <p class="text-color-white"><?php echo _e($dataArr[2][0]['name'],'adivaha-widget')?></p>
                                        <h3 class="text-color-white"><?php echo _e($dataArr[2][0]['description'],'adivaha-widget')?></h3>
                                    </div>
                                    <div class="hoverlayboxcolor">
                                        <a href="<?php echo $dataArr[2][0]['url']?>" class="city-text text-color-white"><?php echo _e($dataArr[2][0]['name'],'adivaha-widget')?></a>
                                        <a href="<?php echo $dataArr[2][0]['url']?>" class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde">Find The Best</a>
                                    </div>
                                    <div class="hover-overlay"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="section-two adi-full oneFiex3">
                        <div class="adi-max-width">
                            <div class="adi-col-4 adi-left padding-right-10 padding-bottom-10">
                                <div class="box">
                                    <span class="message"><b class="">BEST DEAL</b></span> <img alt="" src="<?php echo PLUGIN_URL.'img/'.$dataArr[3][0]['image']?>" />
                                    <div class="box-content padding-20">
                                        <p class="text-color-white"><?php echo _e($dataArr[3][0]['name'],'adivaha-widget')?></p>
                                        <h3 class="text-color-white"><?php echo _e($dataArr[3][0]['description'],'adivaha-widget');?></h3>
                                    </div>
                                    <div class="hoverlayboxcolor">
                                        <a href="<?php echo $dataArr[3][0]['url']?>" class="city-text text-color-white"><?php echo _e($dataArr[3][0]['name'],'adivaha-widget')?></a>
                                        <a href="<?php echo $dataArr[3][0]['url']?>" class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde">Find The Best</a>
                                    </div>
                                    <div class="hover-overlay"></div>
                                </div>
                            </div>
                            <div class="adi-col-4 adi-left padding-right-10 padding-bottom-10">
                                <div class="box">
                                    <span class="message"><b class="">BEST DEAL</b></span>
                                    <!--<img alt="" src=" https://www.triparison.com/wp-content/uploads/2020/07/10.jpg">-->
                                    <img alt="" src="<?php echo PLUGIN_URL.'img/'.$dataArr[4][0]['image']?>" />
                                    <div class="box-content padding-20">
                                        <p class="text-color-white"><!--Isle of Wight --><?php echo _e($dataArr[4][0]['name'],'adivaha-widget')?></p>
                                        <h3 class="text-color-white"><!--Island off England</h3>--><?php echo _e($dataArr[4][0]['description'],'adivaha-widget')?></h3>
                                    </div>
                                    <div class="hoverlayboxcolor">
                                        &lt;--<a href="<?php echo $dataArr[4][0]['url']?>" class="city-text text-color-white"><?php echo _e($dataArr[4][0]['name'],'adivaha-widget')?> </a>--&gt;
                                        <a
                                            href="<?php echo $dataArr[4][0]['url']?>"
                                            class="city-text text-color-white"
                                        >
                                            <?php echo _e($dataArr[4][0]['name'],'adivaha-widget')?>
                                        </a>
                                        <!--<a href="https://www.triparison.com/hotel-in-england/" class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde">Find The Best</a>-->
                                        <a
                                            href="<?php echo $dataArr[4][0]['url']?>"
                                            class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde"
                                        >
                                            Find The Best
                                        </a>
                                    </div>
                                    <div class="hover-overlay"></div>
                                </div>
                            </div>
                            <div class="adi-col-4 adi-left padding-bottom-10">
                                <div class="box">
                                    <span class="message"><b class="">BEST DEAL</b></span>
                                    <!--<img alt="" src="https://www.triparison.com/wp-content/uploads/2020/07/9.jpg">-->
                                    <img alt="" src="<?php echo PLUGIN_URL.'img/'.$dataArr[5][0]['image']?>" />
                                    <div class="box-content padding-20">
                                        <p class="text-color-white"><!--Leeds --><?php echo _e($dataArr[5][0]['name'],'adivaha-widget')?></p>
                                        <h3 class="text-color-white"><!--United Kingdom--><?php echo _e($dataArr[5][0]['description'],'adivaha-widget')?></h3>
                                    </div>
                                    <div class="hoverlayboxcolor">
                                        <!--<a href="https://www.triparison.com/hotel-in-leeds/" class="city-text text-color-white">Leeds </a>-->
                                        <a
                                            href="<?php echo $dataArr[5][0]['url']?>"
                                            class="city-text text-color-white"
                                        >
                                            Leeds
                                        </a>
                                        <!--<a href="https://www.triparison.com/hotel-in-leeds/" class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde">Find The Best</a>-->
                                        <a
                                            href="<?php echo $dataArr[5][0]['url']?>"
                                            class="adi-btn text-color-white margin-top-10 btnbkcolorBTNde"
                                        >
                                            Find The Best
                                        </a>
                                    </div>
                                    <div class="hover-overlay"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        .body-title {
        }
        .body-paragraph {
            padding-top: 5px;
            color: #333;
            width: 100%;
            font-size: 16px;
            line-height: 28px;
            font-weight: 400;
        }
        .box {
            box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.2);
            position: relative;
            overflow: hidden;
            cursor: pointer;
        }
        .box img {
            height: 100% !important;
        }
        .message {
            font-size: 9px;
            color: #fff;
            text-transform: uppercase;
            text-align: center;
            line-height: 20px;
            transform: rotate(45deg);
            -webkit-transform: rotate(45deg);
            width: 100px;
            display: block;
            background: #009688;
            box-shadow: 0 3px 10px -5px rgba(0, 0, 0, 1);
            position: absolute;
            top: 19px;
            right: -21px;
        }
        .box-content {
            position: absolute;
            bottom: 0px;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 1));
            left: 0px;
            right: 0px;
        }
        .box-content p {
            color: #fff;
            font-size: 15px;
        }
        .box-content h3 {
            color: #fff;
            font-weight: 600;
            font-size: 20px;
            padding-top: 5px;
        }
        .oneFiex1 .box {
            height: 400px;
        }
        .oneFiex2 .box {
            height: 195px;
        }
        .oneFiex3 .box {
            height: 250px;
        }
        .oneFiex4 .box {
            height: 195px;
        }
        .oneFiex5 .box {
            height: 400px;
        }
        .hover-overlay {
            position: absolute;
            top: 0;
            bottom: 0;
            transform: translateY(0%);
            -webkit-transform: translateY(100%);
            -moz-transform: translateY(100%);
            -ms-transform: translateY(100%);
            -o-transform: translateY(100%);
            background: rgba(275, 275, 275, 0.8) !important;
            transition: 0.4s ease-in-out;
            -webkit-transition: 0.4s ease-in-out;
            -moz-transition: 0.4s ease-in-out;
            -ms-transition: 0.4s ease-in-out;
            -o-transition: 0.4s ease-in-out;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 1));
            width: 100%;
            left: 0px;
            right: 0px;
            padding: 19% 16% 16% 16%;
            text-align: center;
        }
        .box:hover .hover-overlay {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0px;
            right: 0px;
            transform: translateY(0%);
            -webkit-transform: translateY(0%);
            -moz-transform: translateY(0%);
            -ms-transform: translateY(0%);
            -o-transform: translateY(0%);
            background: rgba(275, 275, 275, 0.8) !important;
            transition: 0.4s ease-in-out;
            -webkit-transition: 0.4s ease-in-out;
            -moz-transition: 0.4s ease-in-out;
            -ms-transition: 0.4s ease-in-out;
            -o-transition: 0.4s ease-in-out;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0), rgba(0, 0, 0, 1));
            width: 100%;
        }
        .city-text {
            display: inline-block;
            text-align: center !important;
            width: 100%;
            margin-bottom: 20px;
            font-size: 20px !important;
        }
        .oneFiex1 .box a:hover {
            color: #fff;
        }
        .oneFiex2 .box a:hover {
            color: #fff;
        }
        .oneFiex3 .box a:hover {
            color: #fff;
        }
        .oneFiex4 .box a:hover {
            color: #fff;
        }
        .oneFiex5 .box a:hover {
            color: #fff;
        }
        .box img {
            width: 100%;
        }
        .adi-btn {
            display: inline-block;
            font-size: 15px;
            background-color: #009688;
            margin: 0 auto;
            padding: 10px 25px 10px 25px;
            border-radius: 0px;
            text-align: center;
        }
        @media (max-width: 767px) {
            .oneFiex5 {
                margin-top: 10px;
            }
            .body-paragraph {
                width: 100%;
            }
            .adi-col-4,
            .adi-col-6 {
                width: 100%;
            }
            .body-title {
            }
            .oneFiex1 .box,
            .oneFiex5 .box {
                height: 250px !important;
            }
        }
    </style>
    <style>
        .body-title {
        }
        .body-paragraph {
        }
        .box:hover .hover-overlay {
            background: #ffffff;
            opacity: 0.5 !important;
        }
        .message {
            background: #ffffff;
            color: #ffffff !important;
        }
        .btnbkcolorBTNde {
            background-color: #ffffff !important;
            color: #ffffff !important;
        }
        .hoverlayboxcolor {
            position: absolute;
            top: 0;
            bottom: 0;
            transform: translateY(0%);
            -webkit-transform: translateY(100%);
            -moz-transform: translateY(100%);
            -ms-transform: translateY(100%);
            -o-transform: translateY(100%);
            transition: 0.4s ease-in-out;
            -webkit-transition: 0.4s ease-in-out;
            -moz-transition: 0.4s ease-in-out;
            -ms-transition: 0.4s ease-in-out;
            -o-transition: 0.4s ease-in-out;
            width: 100%;
            left: 0px;
            right: 0px;
            padding: 19% 16% 16% 16%;
            text-align: center;
            z-index: 999;
        }
        .box:hover .hoverlayboxcolor {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0px;
            right: 0px;
            transform: translateY(0%);
            -webkit-transform: translateY(0%);
            -moz-transform: translateY(0%);
            -ms-transform: translateY(0%);
            -o-transform: translateY(0%);
            transition: 0.4s ease-in-out;
            -webkit-transition: 0.4s ease-in-out;
            -moz-transition: 0.4s ease-in-out;
            -ms-transition: 0.4s ease-in-out;
            -o-transition: 0.4s ease-in-out;
            width: 100%;
        }
        .feature_class {
            display: none !important;
        }
        .service-add-wishlist {
            display: none !important;
        }
    </style>

