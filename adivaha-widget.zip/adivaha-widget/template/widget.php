<?php
$tablename = "adh_widget"; 
if(isset($_REQUEST['submit'])){
	$name = $_REQUEST['dest_name'];
	
	$description = $_REQUEST['destDescription'];
	$rating = $_REQUEST['rating'];
	$rating = $_REQUEST['rating'];
	//$image =  $_REQUEST['dest_image'];
	 $file_extension = pathinfo($_FILES["dest_image"]["name"], PATHINFO_EXTENSION);
	  $fileFormateArr = array('png','jpg','jpeg');
	  if(in_array($file_extension,$fileFormateArr)){
	  	$tmpname = $_FILES["dest_image"]["tmp_name"];
	  	$fileOname = $_FILES["dest_image"]["name"];
	  	$target = PLUGIN_DIR."img/".$fileOname;

	  	move_uploaded_file($tmpname,$target);
	  	 $destUrl = $_REQUEST['destUrl'];
	if($name!=''){
		$data = array('name'=>$name,'description'=>$description,'rating'=>$rating,'image'=>$fileOname,'url'=>$destUrl);
		$wpdb->query("insert into ".$tablename." set title='pop_dest', data='".addslashes(json_encode($data))."',name='".$name."', delete_status='0',date_time=now()");
	}
		
	}else{
		echo "File Formate Not Supporting";
	}

}

?>
<body>
	<style>
		.mytble{
	width:100%;margin-top:4%;
}
.mytble td{
	padding-left:12px;
	
}
#widgetbtn{
	padding: 4px 8px;
    position: relative;
    top: -3px;
    text-decoration: none;
    border: 1px solid #0071a1;
    border-radius: 2px;
    text-shadow: none;
    font-weight: 600;
    font-size: 13px;
    line-height: normal;
    color: #0071a1;
    background: #f3f5f6;
    cursor: pointer;
}
.overlay {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  width: 100px;
  opacity: 0;
  transition: .5s ease;
  background-color: #abadad;
}
.overlay .text{
	    font-size: 48px;
    text-align: center;
    margin-top: 9%;
}
.imagehover{
	position: relative;
}
.imagehover:hover .overlay {
  opacity: 1;
}
		input,select{float:left;
			width:100%;
			margin:5px;}
			form{width:50%;}
	</style>
	<h2>Add Popular Destination <button id="widgetbtn">Add New</button></h2>
	
	<div id="addnewwidget" style="display:none;">
	<form action="#" method="post" enctype='multipart/form-data'>
		<input type="text" placeholder="Destination Name" name="dest_name">
		<input type="text" placeholder="Destionation Location" name="destDescription">
		<input type="text" name="destUrl" placeholder="Destination URL">

		<select name="rating">
			<option value="None" selected>Select Rating</option>
			<option value="0">0</option>
 
		<option value="1">1</option>
	
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
</select>
   <input type="file" name="dest_image">
		<input type="submit" name="submit" value="submit">
	</form>
</div>
	<?php echo do_shortcode('[Get_Popular_Destination]');?>
	</body>
<html>

<script>
	jQuery(document).ready(function(){
		jQuery("#widgetbtn").click(function(){
			jQuery("#addnewwidget").slideToggle();

			
		})
	})
	</script>
	