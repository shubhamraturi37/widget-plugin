<?php 
global $wpdb;
$tablename =  "adh_widget"; 
$page = $_REQUEST['page'];
$getresult = $wpdb->get_results("select * from ".$tablename." where delete_status='0' and title='trip'");
$trashdata = $wpdb->get_results("select * from ".$tablename." where delete_status='1' and title='trip'");

function current_location()
{
    if (isset($_SERVER['HTTPS']) &&
        ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
        isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
        $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
        $protocol = 'https://';
    } else {
        $protocol = 'http://';
    }
    return $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}



if(isset($_REQUEST['action']) && $_REQUEST['action']=='trash'){
	if($_REQUEST['destId']!=''){
		
		$wpdb->query("update ".$tablename." set delete_status='1' where id='".$_REQUEST['destId']."' and title='trip'");
		
		echo "<script>window.location.href='?page=".$page."'</script>";

	}
}
if(isset($_REQUEST['action']) && $_REQUEST['action']=='delete'){
	if($_REQUEST['destId']!=''){
		
		$wpdb->query("delete from ".$tablename."  where id='".$_REQUEST['destId']."' and title='trip'");
		
		echo "<script>window.location.href='?page=".$page."'</script>";

	}
}
if(isset($_REQUEST['action']) && $_REQUEST['action']=='restore'){
	if($_REQUEST['destId']!=''){
		
		$wpdb->query("update ".$tablename." set delete_status='0' where id='".$_REQUEST['destId']."' and title='trip'");
		
		echo "<script>window.location.href='?page=".$page."'</script>";

	}
}

if(isset($_REQUEST['action']) && $_REQUEST['action']=='updatedest'){
	$image = $_REQUEST['image'];
	if($_REQUEST['id']!=''){
	$newimge = $_FILES["newimg"]["name"];
    $fileNameTxt='';
	if($newimge!=''){
	 $file_extension = pathinfo($_FILES["newimg"]["name"], PATHINFO_EXTENSION);
	  $fileFormateArr = array('png','jpg','jpeg');
	  if(in_array($file_extension,$fileFormateArr)){
	  	$tmpname = $_FILES["newimg"]["tmp_name"];
	  	$fileOname = $_FILES["newimg"]["name"];
	  	$target = PLUGIN_DIR."img/".$fileOname;
        move_uploaded_file($tmpname,$target);
      
        $image = $fileOname;
	  	 }
	  	}
	  	$data = array('name'=>$_REQUEST['destname'],'description'=>$_REQUEST['description'],'rating'=>$_REQUEST['rating'],'image'=>$image,'url'=>$_REQUEST['desturl'],'review'=>$_REQUEST['review']);
	  	
		$wpdb->query("update ".$tablename." set data='".addslashes(json_encode($data))."' where id='".$_REQUEST['id']."' and title='trip'");
		
		echo "<script>window.location.href='?page=".$page."'</script>";
	}
}

?>
<!-- 
<table  class="mytble">
	<thead>
		<tr>
			<th>Sn.</th><th>Name</th><th>Description</th><th>Image</th><th>Rating</th><th>URL</th><th></th><th></th>
		</tr>
	</thead>
	<tbody>
		<?php 
       foreach($getresult as $key=>$data){

       ?>
   <tr>
		<td><?php echo $key+1; ?></td>
		<td><?php echo $data->destname; ?></td>
		<td><?php echo $data->dest_description; ?></td>
		<td><img width="100px" height="50px" src="<?php echo PLUGIN_URL.'img/'.$data->dest_img; ?>"></td>
		<td><?php echo $data->dest_rating; ?></td>
		<td><?php echo $data->dest_URL; ?></td>
		<td><button id="editbtn" value="<?php echo $data->id;?>">Edit</button></td>
		<td><button id="deletebtn" value="<?php echo $data->id?>">Delete</button></td>
	</tr>


       	<?php 
       }

		?> 
	</tbody>
	
	</table> -->
	<ul class="subsubsub">
	<li class="all"><a href="?page=<?php echo $page?>&page_status=all" class="<?php if($_REQUEST['page_status']=='all' || $_REQUEST['page_status']==''){echo 'current';}?>" aria-current="page">All <span class="count">(<?php echo count($getresult); ?>)</span></a> |</li>
	<li class="publish"><a href="?page=<?php echo $page?>&page_status=published" class="<?php if($_REQUEST['page_status']=='published'){echo 'current';}?>">Published <span class="count">(<?php echo count($getresult); ?>)</span></a> |</li>
	<li class="trash"><a href="?page=<?php echo $page?>&page_status=trash" class="<?php if($_REQUEST['page_status']=='trash'){echo 'current';}?>">Trash <span class="count">(<?php echo count($trashdata); ?>)</span></a></li>
</ul>
	<table class="wp-list-table widefat fixed striped posts">
	<thead>
	<tr>
		<td id="cb" class="manage-column column-cb check-column"><label class="screen-reader-text" for="cb-select-all-1">Select All</label><input id="cb-select-all-1" type="checkbox"></td><th scope="col" id="title" style="width:8%" class="manage-column column-title column-primary sortable desc"><a href="#"><span>Title</span><span class="sorting-indicator"></span></a></th><th style="width:20%" scope="col" id="author" class="manage-column column-author">Location</th><th scope="col" id="categories" class="manage-column column-categories">URL</th><th scope="col" id="tags" class="manage-column column-tags">Image</th><th scope="col" id="comments" class="manage-column column-comments num sortable desc">Rating</th><th scope="col" id="comments" class="manage-column column-comments num sortable desc">Reviews</th><th scope="col" id="date" class="manage-column column-date sortable asc"><a href="#"><span>Date</span><span class="sorting-indicator"></span></a></th>	</tr>
	</thead>

	<tbody id="the-list">
		<?php 
		if(isset($_REQUEST['page_status']) && $_REQUEST['page_status']=='trash'){
$getresult = $trashdata;	
}
       foreach($getresult as $key=>$data){
       	$getArr = json_decode($data->data,true);
        
       ?>
				<tr id="dest-<?php echo $data->id; ?>" class="iedit author-self level-0 dest-<?php echo $data->id; ?> type-post status-publish format-standard hentry category-service">
			<th scope="row" class="check-column">			<label class="screen-reader-text" for="cb-select-35">
				Select <?php echo $getArr['name']; ?>			</label>
			<input id="cb-select-35" type="checkbox" name="post[]" value="35">
			<div class="locked-indicator">
				<span class="locked-indicator-icon" aria-hidden="true"></span>
				<span class="screen-reader-text">
				“<?php echo $getArr['name']; ?>” is locked				</span>
			</div>
			</th><td class="title column-title has-row-actions column-primary page-title" data-colname="Title"><div class="locked-info"><span class="locked-avatar"></span> <span class="locked-text"></span></div>
<strong><a class="row-title" href="#" aria-label="“service” (Edit)"><?php echo $getArr['name']; ?></a></strong>

<div class="hidden" id="inline_35">
	<div class="post_title"><?php echo $getArr['name']; ?></div><div class="post_name"><?php echo $getArr['name']; ?></div>

	<div class="post_password"></div><div class="page_template">default</div><div class="post_category" id="category_35">3</div><div class="tags_input" id="post_tag_35"></div><div class="sticky"></div><div class="post_format"></div></div><div class="row-actions">
		<?php 
      if(isset($_REQUEST['page_status']) && $_REQUEST['page_status']=='trash'){
		?>
		<a href="<?php echo '?page='.$page.'&action=restore&destId='.$data->id?>" class="submitdelete" aria-label="Move “service” to the Trash">Restore |</a><span class="trash">
		<a href="<?php echo '?page='.$page.'&action=delete&destId='.$data->id?>" class="submitdelete" aria-label="Move “service” to the Trash">Delete Permanently</a></span>
	<?php }else{
		 ?>
		 <span class="inline hide-if-no-js"><button type="button" class="button-link editinline" rel="<?php echo $data->id;?>" aria-label="Quick edit “service” inline" aria-expanded="true">Edit</button> | </span><span class="trash">
		 	<a href="<?php echo '?page='.$page.'&action=trash&destId='.$data->id?>" class="submitdelete" aria-label="Move “service” to the Trash">Trash</a></span>
		<?php
	}?>
		 </div><button type="button" class="toggle-row"><span class="screen-reader-text">Show more details</span></button></td><td class="author column-author" data-colname="Author"><a href="#"><?php echo $getArr['description']; ?></a></td><td class="categories column-categories" data-colname="Categories"><a href="#"><?php echo $getArr['url']; ?></a></td><td class="tags column-tags" data-colname="Tags"><span aria-hidden="true"><img width="100px" height="50px" src="<?php echo PLUGIN_URL.'img/'.$getArr['image']; ?>"></span><span class="screen-reader-text">No tags</span></td><td class="comments column-comments" data-colname="Comments">		<div class="post-com-count-wrapper">
		<span aria-hidden="true"><?php echo $getArr['rating']; ?></span><span class="post-com-count post-com-count-pending post-com-count-no-pending"><span class="comment-count comment-count-no-pending" aria-hidden="true">0</span><span class="screen-reader-text">No comments</span></span>		</div>
		</td><td class="comments column-comments" data-colname="Comments">		<div class="post-com-count-wrapper">
		<span aria-hidden="true"><?php echo $getArr['review']; ?></span><span class="post-com-count post-com-count-pending post-com-count-no-pending"><span class="comment-count comment-count-no-pending" aria-hidden="true">0</span><span class="screen-reader-text">No comments</span></span>		</div>
		</td><td class="date column-date" data-colname="Date">Published<br><span title="<?php echo $data->date_time;?>"><?php echo date("Y/m/d",strtotime($data->date_time))?></span></td>		</tr>
		<tr id="destshow-<?php echo $data->id; ?>" class="destshow" style="display:none;">
			<form method="post" action="#" id="destForm-<?php echo $data->id; ?>" enctype='multipart/form-data'>
			<td></td>
			<td><input type="text" value="<?php echo $getArr['name']; ?>" name="destname">
				<input type="hidden" name="id" value="<?php echo $data->id; ?>">
				<input type="hidden" name="image" value="<?php echo $getArr['image']; ?>">
				<input type="hidden" name="action" value="updatedest"></td>
			<td><input type="text" value="<?php echo $getArr['description']; ?>" name="description"></td>
			<td><input type="text" value="<?php echo $getArr['url']; ?>" name="desturl"></td>
			<td><div aria-hidden="true" class="imagehover"><img width="100px" height="50px" src="<?php echo PLUGIN_URL.'img/'.$getArr['image']; ?>"><div class="overlay">
    <div class="text plusbtn plusbtn-<?php echo $data->id; ?>" rel="<?php echo $data->id; ?>">+<input type="file" name="newimg" style="height: 63px;z-index: 9999;opacity: 0;margin-top: -25px;"></div></div>
  </div></td>
				<td><input type="text" value="<?php echo $getArr['rating']; ?>" name="rating"></td>
				<td><input type="text" value="<?php echo $getArr['review']; ?>" name="review"></td>
				<td><button id="updatebtn-<?php echo $data->id; ?>" class="updatebtn" rel="<?php echo $data->id; ?>">Update</button></td>
			</form>
		</tr>
			<?php }?>	
	</tfoot>

</table>
<script>
	jQuery(document).ready(function(){
		
		jQuery(".editinline").click(function(){
          jQuery('.destshow').hide();
          jQuery(".iedit").show();
			var rel = jQuery(this).attr('rel');
			jQuery("#dest-"+rel).hide();
			jQuery("#destshow-"+rel).show();

		})
		jQuery(".updatebtn").click(function(){
		var rel = jQuery(this).attr('rel');
		jQuery("#destForm-"+rel).submit();
		})
		jQuery(".text").click(function(){

		})
	})
</script>