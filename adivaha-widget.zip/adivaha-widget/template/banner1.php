<?php

$prefix ='banner_1001_';


$data = $wpdb->get_results("select data from adh_widget where title='bannerData'");
$dataArr = json_decode($data[0]->data);
$dataArr= $dataArr[0];

if($dataArr->banner_1001_flightBannerText == "") { $flightBannerText = "We' re here to take you there"; }else{ $flightBannerText = stripslashes($dataArr->banner_1001_flightBannerText); }
if($dataArr->banner_1001_hotelBannerText == "") { $hotelBannerText = "Book your home away from home"; }else{ $hotelBannerText = stripslashes($dataArr->banner_1001_hotelBannerText); }
if($dataArr->banner_1001_carBannerText == "") { $carBannerText = "Lets find you a Ride"; }else{ $carBannerText = stripslashes($dataArr->banner_1001_carBannerText); }
if($dataArr->banner_1001_transferBannerText == "") { $transferBannerText = "Lets find you a Ride"; }else{ $transferBannerText = stripslashes($dataArr->banner_1001_transferBannerText); }

wp_enqueue_script( 'jquery' );wp_enqueue_style('ui-materialize-banner');
wp_enqueue_script( 'materializejs' );wp_enqueue_script( 'ui-materialize-css' );

?>
<div class="slider" style="width:100%;height:680px">

<ul class="slides" style=""> 

<div class="banner_text_pragraf">  

<div class="adi-max-width">
<!--<div class="book_a_flight1"><p class="book_a_flight_title">'.$flightBannerText.'</p> 
<p class="book_a_flight_pargraf">Search hundreds of travel sites at once</p>
</div> -->

<div class="book_a_flight"><p class="book_a_flight_title"><?php echo _e($flightBannerText,'adivaha-widget') ?></p> 
<!--<p class="book_a_flight_pargraf">Search hundreds of travel sites at once</p>-->
</div> 
<div class="book_a_hotle"><p class="book_a_flight_title"><?php echo _e($hotelBannerText,'adivaha-widget') ?></p>  
<!--<p class="book_a_flight_pargraf">Explore thousands of hotel booking sites at once</p>--></div>
<div class="book_a_car"><p class="book_a_flight_title"><?php echo _e($carBannerText,'adivaha-widget') ?></p> 
<!--<p class="book_a_flight_pargraf">Search hundreds of travel sites at once</p>-->
</div>
<div class="book_a_car_transfers"><p class="book_a_flight_title"><?php echo _e($transferBannerText,'adivaha-widget') ?></p> 
<!--<p class="book_a_flight_pargraf">Search hundreds of travel sites at once</p>-->
</div>  

</div>   

</div>
<?php


$adhbanners =$globRest['adhbanners'];


$adhbannersTitle =$globRest['adhbanners'][$prefix.'title'];


if(count($adhbannersTitle)>0){


$countBanner =count($adhbannersTitle);


}else{


$countBanner =1;


$adhbanners=array();	


}








for($i=0;$i<$countBanner;$i++){


 $bannertitle =$adhbanners[$prefix.'title'][$i];


 $bannerdescription =$adhbanners[$prefix.'description'][$i];


 $bannerimg =$adhbanners[$prefix.'thumbnail'][$i];


 


if($bannerimg==''){$bannerimg = get_template_directory_uri()."/images/banner/1.jpg"; }


if($bannertitle =='') { $bannertitle = "AUSSIE Travel Agent ROCK!"; }


if($bannerdescription=='') { $bannerdescription = "“For my part, I travel not to go anywhere, but to go. I travel for travel’s sake. The great affair is to move.” – Robert Louis Stevenson"; }
/*
trim( $_SERVER["REQUEST_URI"] , '/' )


echo "mukess";
echo $pagename;
die;


 if (trim( $_SERVER["REQUEST_URI"] , '/airport-transfers' ) ){
	 

}
*/

if ( is_front_page() ) {
	
	
	 }else {
		 
	
	
	
$html.='<li><div class="imageDiv">


<video  autoplay loop muted playsinline  width="1920" height="768" id="playvideo_1">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-pink-sunset-seen-from-a-plane-window-4204-large.mp4" type="video/mp4">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-pink-sunset-seen-from-a-plane-window-4204-large.mp4" type="video/ogg">
  
</video>

<video  autoplay loop muted playsinline  width="1920" height="768" id="playvideo_2">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-swiming-pool-in-resort-garden-6773-large.mp4" type="video/mp4">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-swiming-pool-in-resort-garden-6773-large.mp4" type="video/ogg">
  
</video>


<video autoplay loop muted playsinline  width="1920" height="768" id="playvideo_3">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-woman-getting-into-drivers-seat-of-luxury-vehicle-73-large.mp4" type="video/mp4">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-woman-getting-into-drivers-seat-of-luxury-vehicle-73-large.mp4" type="video/ogg">
  
</video>


<video autoplay loop muted playsinline  width="1920" height="768" id="playvideo_4">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-beach-tourist-paradise-2884-large.mp4" type="video/mp4">
  <source src="https://assets.mixkit.co/videos/preview/mixkit-beach-tourist-paradise-2884-large.mp4" type="video/ogg">
  
</video>


<div class="overlayBanner"></div>

</div>


<div class="adi-max-width"><div class="caption center-align" style="display:none"> <h3>'.$bannertitle.'</h3><h2 style="display:none">Book Now &amp; Save!</h2><h5 class="light grey-text text-lighten-3">'.$bannerdescription.'</h5></div></div> 



</li>



';

 }
}








$html.='</ul></div><div class="responsive-video12"><div class="responsive-video">


<video autoplay loop muted playsinline width="1920" height="768" id="widget2"  class="playvideo"
 src="'.$dataArr->banner_1001_videourlput.'">
 
</video>



</div></div>


<style>.slider{height:'.$sliderheight.'px;}.imageDiv,.slides{height:'.$sliderheight.'px;}.overlayBanner{width:100%;height:100%;top:0;left:0;right:0;bottom:0;


background: linear-gradient(135deg, '.$overlay_banner_color.' 0%, '.$overlay_banner_color1.' 100%)!important;cursor:pointer;user-select:none;z-index:0;position:absolute;opacity: 0.'.$overlay_trans.';}.slides h3{color: '.$title_color.' !important;}.slides h5{color: '.$content_color.' !important;}@media only screen and (max-width: 1024px){.slider{height:'.$sliderheights.'px;}.imageDiv,.slides{height:'.$sliderheights.'px;}}  .banner_text_pragraf{position: relative;top: 140px;z-index: 99999;} .book_a_flight{} .book_a_flight_title{color: #fff;font-size: 38px;} .book_a_flight_pargraf{font-size: 15px;color: #fff;margin-top: 16px;} .book_a_hotle{display: none;} .book_a_car{display: none;} .book_a_car_transfers{display: none;}</style>';
echo $html;
