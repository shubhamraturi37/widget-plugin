<?php 
/*
Plugin Name: Adivaha - widget
Plugin URI: http://www.adivaha.com
Description: This plugin has been generated for the CBT...
Author: Shubham
Version: 1.0
Author URI: http://www.adivaha.com
*/
global $wpdb;
define('PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define('PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/*echo ADIVAHA_CORPORATE_PLUGIN_DIR.'apps/dashboard/functions.php';
include('/home1/twcfivco/public_html/demo/travelpa/wp-includes/shortcodes.php');*/
register_activation_hook(__FILE__,'adivaha_widget_pro_install_portal');
register_deactivation_hook(__FILE__ , 'adivaha_widget_pro_uninstall_portal' );
function adivaha_widget_pro_install_portal(){ 
	require_once( PLUGIN_DIR.'template/createTLB.php' );
	
}
function adivaha_widget_pro_uninstall_portal(){ 
global $wpdb;	
}
add_action('admin_menu', 'Adivaha_widget_Detail');
function Adivaha_widget_Detail(){
    
    add_menu_page('Adivaha Widget', 'Adivaha Widget', 'manage_options', 'theme-options','About_ShortCodes');
    add_submenu_page( 'theme-options', 'Popular Destination', 'Popular Destination', 'manage_options', 'Popular Destination', 'Add_Popular_Destination'); 
     add_submenu_page( 'theme-options', 'Inspiration Trip', 'Inspiration Trip', 'manage_options', 'Inspiration Trip', 'Add_Inspiratoin_Trip'); 
     add_submenu_page( 'theme-options', 'Banner', 'Banner', 'manage_options', 'Banner', 'Add_Banner'); 
	 add_submenu_page( 'theme-options', 'Separator', 'Separator', 'manage_options', 'Separator', 'Add_Separator');
	  add_submenu_page( 'theme-options', 'travel_agent', 'Travel Agent', 'manage_options', 'travel_agent', 'Add_Travel_agent');
}
function About_ShortCodes($atts){
 include(PLUGIN_DIR."template/about_shortcode.php");

// menu functions
}
function Add_Popular_Destination($atts){
	
global $wpdb;
include(PLUGIN_DIR."template/widget.php");
die;
return ob_get_clean();
die;
}

function Add_Inspiratoin_Trip($atts){
global $wpdb;
include(PLUGIN_DIR."template/widget_inspire_trip.php");
die;
return ob_get_clean();
}
function Add_Banner($atts){
global $wpdb;
include(PLUGIN_DIR."template/widget_banner.php");
die;
return ob_get_clean();
}
function Add_Separator($atts){
global $wpdb;
include(PLUGIN_DIR."template/widget_seprator.php");
die;
return ob_get_clean();
}
function Add_Travel_agent($atts){
global $wpdb;
include(PLUGIN_DIR."template/widget_travel_agent.php");
die;
return ob_get_clean();
}

//get result data shortcode
add_shortcode("Get_Popular_Destination","Get_Popular_Destination");
function Get_Popular_Destination($atts){
	global $wpdb;
	include(PLUGIN_DIR."template/getresult/getPopularDest.php");
return ob_get_clean();
}
add_shortcode("Get_Inspire_Trip","Get_Inspire_Trip");
function Get_Inspire_Trip($atts){
	global $wpdb;
	include(PLUGIN_DIR."template/getresult/getInspireTrip.php");
return ob_get_clean();
}
add_shortcode("Get_Banner","Get_Banner");
function Get_Banner($atts){
	global $wpdb;
	include(PLUGIN_DIR."template/getresult/getBanner.php");
return ob_get_clean();
}
add_shortcode("Get_seprator","Get_seprator");
function Get_seprator($atts){
	global $wpdb;
	include(PLUGIN_DIR."template/getresult/getSeprator.php");
return ob_get_clean();
}
add_shortcode("Get_travel_agent","Get_travel_agent");
function Get_travel_agent($atts){
	global $wpdb;
	include(PLUGIN_DIR."template/getresult/getTravelAgent.php");
return ob_get_clean();
}



// UI shortcodes
add_shortcode("Adivaha_Popular_Destination","Adivaha_Popular_Destination");
function Adivaha_Popular_Destination($atts){
	  ob_start();
	global $wpdb;
	include(PLUGIN_DIR."template/popular_dest.php");
return ob_get_clean();
}
add_shortcode("Adivaha_Inspiration_trip","Adivaha_Inspiration_trip");
function Adivaha_Inspiration_trip($atts){
	  ob_start();
	global $wpdb;
	include(PLUGIN_DIR."template/Inpiration_trip.php");
return ob_get_clean();
}
add_shortcode("Adivaha_Banner","Adivaha_Banner");
function Adivaha_Banner($atts){
	  ob_start();
	global $wpdb;
	include(PLUGIN_DIR."template/banner.php");
return ob_get_clean();
}
add_shortcode("Adivaha_Seprator","Adivaha_Seprator");
function Adivaha_Seprator($atts){
	  ob_start();
	global $wpdb;
	include(PLUGIN_DIR."template/adh_seprator.php");
return ob_get_clean();
}


?>